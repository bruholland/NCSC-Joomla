<?php

/**
 * @package     Joomla.Site
 * @subpackage  Templates.NCSC
 *
 * @copyright   (C) 2024 NCSC
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * This is a heavily stripped down/modified version of the default Cassiopeia template, designed to build new templates off of.
 */

defined('_JEXEC') or die;  //required for basically ALL php files in Joomla, for security. Prevents direct access to this file by url.

//Imports ("use" statements) - objects from Joomla that we want to use in this file
use Joomla\CMS\Factory; // Factory class: Contains static methods to get global objects from the Joomla framework. Very important!
use Joomla\CMS\HTML\HTMLHelper; // HTMLHelper class: Contains static methods to generate HTML tags.
use Joomla\CMS\Language\Text; // Text class: Contains static methods to get text from language files
use Joomla\CMS\Uri\Uri; // Uri class: Contains static methods to manipulate URIs.

/** @var Joomla\CMS\Document\HtmlDocument $this */

$app = Factory::getApplication();
$wa  = $this->getWebAssetManager();  // Get the Web Asset Manager - used to load our CSS and JS files

// Add Favicon from images folder
$this->addHeadLink(HTMLHelper::_('image', 'favicon.ico', '', [], true, 1), 'icon', 'rel', ['type' => 'image/x-icon']);


// Detecting Active Variables
$option   = $app->input->getCmd('option', '');
$view     = $app->input->getCmd('view', '');
$layout   = $app->input->getCmd('layout', '');
$task     = $app->input->getCmd('task', '');
$itemid   = $app->input->getCmd('Itemid', '');
$sitename = htmlspecialchars($app->get('sitename'), ENT_QUOTES, 'UTF-8');
$menu     = $app->getMenu()->getActive();
$pageclass = $menu !== null ? $menu->getParams()->get('pageclass_sfx', '') : '';

//Get params from template styling
//If you want to add your own parameters you may do so in templateDetails.xml
$testparam =  $this->params->get('testparam');

//uncomment to see how this works on site... it just shows 1 or 0 depending on option selected in style config.
//You can use this style to get/set any param according to instructions at https://kevinsguides.com/guides/webdev/joomla4/joomla-4-templates/adding-config
//echo('the value of testparam is: '.$testparam);

// Get this template's path
$templatePath = 'templates/' . $this->template;


//load bootstrap collapse js (required for mobile menu to work)
//this loads collapse.min.js from media/vendor/bootstrap/js - you can check out that folder to see what other bootstrap js files are available if you need them
HTMLHelper::_('bootstrap.collapse');
//dropdown needed for 2nd level menu items
HTMLHelper::_('bootstrap.dropdown');
//You could also load all of bootstrap js with this line, but it's not recommended because it's a lot of extra code that you probably don't need
//HTMLHelper::_('bootstrap.framework');


//Register our web assets (Css/JS) with the Web Asset Manager
//The files are defined in joomla.asset.json!!! If you don't want to use the included CSS or JS, just remove these lines or replace the CSS/JS files with your own code!
$wa->useStyle('template.uswds');
$wa->useStyle('template.ncsc.mainstyles');
$wa->useStyle('template.ncsc.user');
$wa->useStyle('template.ncsc.menu');
$wa->useScript('template.uswds.scripts');
$wa->useScript('template.ncsc.scripts');
$wa->useScript('template.ncsc.endscript');

//Set viewport meta tag for mobile responsiveness -- very important for scaling on mobile devices
$this->setMetaData('viewport', 'width=device-width, initial-scale=1');

?>

<?php // Everything below here is the actual "template" part of the template. Where we put our HTML code for the layout and such. 
?>
<!DOCTYPE html>
<html lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">

<head>
    <link rel="canonical" href="https://www.dni.gov/">
    <link rel="preload" as="image" href="./media/templates/site/ncsc/images/banner/icon-us-flag.svg">
    <link rel="preload" as="image" href="./media/templates/site/ncsc/images/header/NCSCSeal.svg">

    <?php // Loads important metadata like the page title and viewport scaling 
    ?>
    <jdoc:include type="metas" />

    <?php // Loads the site's CSS and JS files from web asset manager 
    ?>
    <jdoc:include type="styles" />
    <jdoc:include type="scripts" />

    <?php /** You can put links to CSS/JS just like any regular HTML page here too, and remove the jdoc:include script/style lines above if you want.
     * Do not delete the metas line though
     * 
     * For example, if you want to manually link to a custom stylesheet or script, you can do it like this:
     * <link rel="stylesheet" href="https://mysite.com/templates/mytemplate/mycss.css" type="text/css" />
     * <script src="https://mysite.com/templates/mytemplate/myscript.js"></script>
     * */
    ?>

</head>

<?php // you can change data-bs-theme to dark for dark mode  // 
?>

<body class="site <?php echo $pageclass; ?>" data-bs-theme="light">
    <header>
        <?php // Load US Banner if Module Exists 
        ?>
        <?php if ($this->countModules('us-banner')) : ?>
            <jdoc:include type="modules" name="us-banner" style="none" />
        <?php endif; ?>

    </header>

    <?php // Load NCSC Logo Banner if Module Exists: Logo, Name, and Hamburger menu  // 
    ?>
    <header>
        <?php if ($this->countModules('ncsc-banner')) : ?>
            <jdoc:include type="modules" name="ncsc-banner" style="none" />
        <?php endif; ?>
    </header>
    <!-- Mega MENU -->
    <div class="usa-overlay"></div>
    <header class="usa-header">
        <nav id="main-nav" class="section-navbar" aria-live="polite">
            <section aria-labelledby="primary-navigation-title" class="sm-nav-width usa-nav">
                <h2 id="primary-navigation-title" class="visually-hidden">Primary Navigation</h2>
                <div class="usa-nav__inner">
                    <?php // Close Hamburger menu icon // 
                    ?>
                    <div class="padding-right-05">
                        <button class="usa-nav__close">
                            <img src="./templates/node_modules/@uswds/uswds/dist/img/usa-icons/close.svg" alt="close">
                        </button>
                    </div>
                    <?php // Mega & Hamburger menu: CSS media qureies changes appearance on zoom or smaller device // 
                    ?>
                    <ul class="usa-nav__primary usa-accordion">
                        <?php if ($this->countModules('ncsc-menu')) : ?>
                            <jdoc:include type="modules" name="ncsc-menu" style="none" />
                        <?php endif; ?>
                    </ul>
                    <?php // Load Search (box) and Socials (links) if Module Exists //
                          // Search box & Social Links. Floated to appear in in Logo banner // 
                    ?>
                    <?php if ($this->countModules('ncsc-search-and-socials')) : ?>
                        <jdoc:include type="modules" name="ncsc-search-and-socials" style="none" />
                    <?php endif; ?>
                </div>
            </section>
        </nav>
    </header>

    <?php // Generate the main content area of the website 
    ?>
    <?php
    $homePage = !$this->countModules('breadcrumbs'); // Home page does not have breadcrumbs
    $html = '<main class="main-content">';
    if ($homePage) {
        $html = str_replace('main-content', 'main-homePage', $html);
    }
    echo $html;
    ?>

    <?php // Load Breadcrumbs Module if Module Exists 
    ?>
    <?php if ($this->countModules('breadcrumbs')) : ?>
        <div class="breadcrumbs">
            <jdoc:include type="modules" name="breadcrumbs" style="none" />
        </div>
    <?php endif; ?>
    <?php // Load sidebar-left and the main component if sidebar-left exists 
    ?>
    <?php if ($this->countModules('sidebar-left')) : ?>
        <div class="grid-row dni-layout-docs pb-2">
            <div class="grid-col-3 layout-sidebar-first">
                <div class="usa-card">
                    <div class="usa-card__body dni-card__body-sidebar-left">
                        <nav aria-labelledby="sidebar-menu-navigation">
                            <h2 class="invisible" id="sidebar-menu-navigation">Sidebar menu navigation</h2>
                            <?php // This line tells Joomla to load the "sidebar-left" module position with the "superBasicMod" mod chrome as the default (see html/layouts/chromes folder) 
                            ?>
                            <jdoc:include type="modules" name="sidebar-left" style="superBasicMod" />
                        </nav>
                    </div>
                </div>
            </div>
            <div class="grid-col-9">
                <div class="usa-card">
                    <article class="usa-card__body dni-card__body-main">
                        <?php // Load important Joomla system messages 
                        ?>
                        <jdoc:include type="message" />
                        <?php // Load the main component of the webpage 
                        ?>
                        <jdoc:include type="component" />
                    </article>
                </div>

            </div>
        </div>
        <?php // If there's no sidebar-left, just load the component without sidebar-left 
        ?>
    <?php else : ?>
        <?php // Load the main component of the webpage 
        ?>
        <div class="pb-5">
            <?php if (!$this->countModules('breadcrumbs')) : ?>
                <div class="grid-row flex-justify banner-homePage">
                    <div class="bannerText-homePage"><span>NCSC</span> &ndash; Leading the effort to protect our nation against intelligence and security threats</div>
                </div>
                <?php if ($this->countModules('ncsc-home-page-message')) : ?>
                    <jdoc:include type="modules" name="ncsc-home-page-message" style="none" />
                <?php endif; ?>
            <?php endif; ?>
            <jdoc:include type="component" />
        </div>
    <?php endif; ?>
    </main>

    <?php // Load Footer 
    ?>
    <button onclick="topFunction()" id="topBtn" title="Go to top">
        <span class="topChevron">Top</span></button>
    
    <?php // Load Footer 1 if Module Exists <footer> // 
        ?>
    <?php if ($this->countModules('ncsc-footer-1')) : ?>
        <jdoc:include type="modules" name="ncsc-footer-1" style="none" />
    <?php endif; ?>

    <?php // Load Footer 2 if Module Exists <footer> // 
        ?>
    <?php if ($this->countModules('ncsc-footer-2')) : ?>
        <jdoc:include type="modules" name="ncsc-footer-2" style="none" />
    <?php endif; ?>

    <?php // Include any debugging info 
    ?>
    <jdoc:include type="modules" name="debug" style="none" />
</body>

</html>