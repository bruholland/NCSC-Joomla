<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_menu
 *
 * @copyright   (C) 2012 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;

$title      = $item->anchor_title ? ' title="' . $item->anchor_title . '"' : '';
$anchor_css = $item->anchor_css ?: '';
$linktype   = $item->title;
if (isset($section_level) && is_numeric($section_level)) {
    $section_level++;
} else {
    $section_level = 1;
}



?>
<?php if ($item->deeper) : ?>
	<li class="usa-nav__primary-item">
                    <button type="button" class="usa-accordion__button usa-nav__link " aria-expanded="false"
                        aria-controls="extended-mega-nav-section-<?php echo $section_level; ?>">
                        <span><?php echo $linktype; ?></span>
                    </button>
                    <div id="extended-mega-nav-section-<?php echo $section_level; ?>" class="usa-nav__submenu usa-megamenu" hidden="">
<?php endif; ?>




