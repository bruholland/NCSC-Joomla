<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_menu
 *
 * @copyright   (C) 2009 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;

?>
<ul class="usa-nav__primary usa-accordion">
<?php 
$ul_level = 0;
$file_list = array("heading", "component", "url", "separator"); 
foreach ($list as $i => &$item)
{
	$itemParams = $item->getParams();
	$class      = ' nav-item-' . $item->id;

	/* This one is not ever called */
	if ($item->id == $default_id)
	{
		$class .= ' default';
	}

	if ($item->id == $active_id || ($item->type === 'alias' && $itemParams->get('aliasoptions') == $active_id))
	{
		$class .= ' usa-current';
	}

	if (in_array($item->id, $path))
	{
		$class .= ' is-active';
	}

	/* This one is probably used if Joomla menu item is a separator. */
	if ($item->type === 'separator')
	{
		$class .= ' divider';
	}

	/* Don't need both deeper and parent -- They identify the same thing */
	// if ($item->deeper)
	// {
	// 	$class .= ' deeper'; // ' usa-nav__primary-item';
	// }

	if ($item->parent)
	{
		$class .= ' parent';
		$ul_level++;
		$class .= ' usa-nav__submenu-list--level-' . $ul_level;

	}

	if ($item->shallower)
	{
		$class .= ' shallower';
		$ul_level--;
	}


	// echo '<li style="border: 1px solid red;">' . $item->title . '&nbsp;&nbsp;&nbsp;' . $item->type;
	// echo '<li class="' . $class . '">';

	if (in_array($item->type, $file_list)) 
	{
		require ModuleHelper::getLayoutPath('mod_menu', 'default_' . $item->type);
	}
	else 
	{
		echo '<li style="border: 1px solid red; color: white;"><span style="color: red;">' . $item->type . '</span> is an unsupported Joomla Menu Item Type for this menu';
	}

	// The next item is deeper.
	if ($item->deeper)
	{
		echo '<ul class="usa-nav__submenu-list usa-nav__submenu-list--level-' . $ul_level + 1 .'">';
	}
	// The next item is shallower.
	elseif ($item->shallower)
	{
		echo '<div style="height: 2px; background: linear-gradient(to right, transparent, #005ea2, #005ea2, transparent, transparent);"></div>';
		echo '</li>';
		echo str_repeat('</ul></li>', $item->level_diff);
	}
	elseif (($item->type === "heading"))
	{
		echo '</div></li>';
	}
	// The next item is on the same level.
	else
	{
		echo '<div style="height: 2px; background: linear-gradient(to right, transparent, #005ea2, #005ea2, #005ea2, transparent, transparent);"></div>';
		echo '</li>';
	}


}
?></ul>
