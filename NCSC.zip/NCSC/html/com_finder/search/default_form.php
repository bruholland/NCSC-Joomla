<?php

/**
 * @package     Joomla.Site
 * @subpackage  com_finder
 *
 * @copyright   (C) 2011 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

/*
* This segment of code sets up the autocompleter.
*/

if ($this->params->get('show_autosuggest', 1)) {
    $this->document->getWebAssetManager()->usePreset('awesomplete');
    $this->document->addScriptOptions('finder-search', ['url' => Route::_('index.php?option=com_finder&task=suggestions.suggest&format=json&tmpl=component', false)]);

    Text::script('JLIB_JS_AJAX_ERROR_OTHER');
    Text::script('JLIB_JS_AJAX_ERROR_PARSE');
}

?>

<form action="<?php echo Route::_($this->query->toUri()); ?>" method="get" class="usa-search usa-search--small ">
    <?php echo $this->getFields(); ?>
    <fieldset class="com-finder__search word mb-3">
        <legend class="com-finder__search-legend visually-hidden">
            <?php echo Text::_('COM_FINDER_SEARCH_FORM_LEGEND'); ?>
        </legend>
        <div class="form-inline">
            <!-- Search (page) -->
            <label for="q" class="me-2">
                <?php echo Text::_('COM_FINDER_SEARCH_TERMS'); ?>
            </label>
            <div class="grid-row flex-justify-start flex-align-center grid-gap">
                <div class="display-flex">
                    <input type="text" name="q" id="q" class="js-finder-search-query form-control" value="<?php echo $this->escape($this->query->input); ?>" placeholder="Search...">
                    <button type="submit" class="btn btn-primary dni-search-btn" title="search">
                        <span class="icon-search icon-white"></span>
                    </button>
                </div>
                <button class="usa-button usa-button--outline radius-md dni-reset" type="button" onclick="document.getElementById('q').value = ''; document.getElementById('q').focus();"> Clear </button>
                <?php
                $modules = JModuleHelper::getModules('back-button');
                if (!empty($modules)) {
                    echo JHtml::_('content.prepare', '{loadposition back-button}');
                }
                ?>
            </div>
        </div>
    </fieldset>

</form>