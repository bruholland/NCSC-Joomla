//You can put your own JS Here!

window.onload = function () {
  // Search focus
  var searchField = document.getElementById("q");
  if (searchField) {
    searchField.focus();
  }
  // Breadcrumb (last item with anchor is static). Small screen media query only shows this item in breadcrumbs.
  const breadcrumbItemsWithAnchors = document.querySelectorAll('li.usa-breadcrumb__list-item:has(a)');
  if (breadcrumbItemsWithAnchors.length > 0) {
    breadcrumbItemsWithAnchors[breadcrumbItemsWithAnchors.length - 1].style.position = 'static';
  }

  
  // // Select all elements with the class 'usa-breadcrumb__list-item'
  // const breadcrumbItems = document.querySelectorAll('.usa-breadcrumb__list-item');

  // // Convert NodeList to Array for easier manipulation
  // const breadcrumbArray = Array.from(breadcrumbItems);

  // // Iterate through the array and remove elements not in the first 3 or the last position
  // // Fixes breadcrumbs for Newsroom Articles. Stops appending categories links to breadcrumb trail.
  // breadcrumbArray.forEach((item, index) => {
  //     if (index >= 3 && index !== breadcrumbArray.length - 1) {
  //         item.remove();
  //     }
  // });

  
  // Removes external link icon from images within an anchor do not have the external link
  // document.querySelectorAll('a[href^="http"]').forEach(anchor => {
  //   if (anchor.nextElementSibling && anchor.nextElementSibling.tagName === 'IMG') {
  //       anchor.style.setProperty('--after-content', 'none');
  //   }
  // });  
  document.querySelectorAll('a[href^="http"]').forEach(anchor => {
    if (anchor.querySelector('img')) {
      anchor.classList.add('no-after');
    }
  });
  var  headings = document.querySelectorAll("h1");
  headings.forEach(function(heading) { 
    if (heading.textContent.includes("Newsroom")) { heading.classList.add("newsroom-img"); } 
  });
};

function removeAriaHidden() {
  // Note: Joomla automatically adds the aria-hidden attribute on the #main-nav element when the hamburger
  // button is clicked. This just waits a split second to remove that attribute to avoid console errors.
  var mainNav = document.getElementById("main-nav");
  setTimeout(function () {
    mainNav.removeAttribute('data-nav-hidden');
    mainNav.removeAttribute('aria-hidden');
  }, 100);
}


// Toggle active class to animate (rotate) chevron in page banner.
let accordion_txt = document.querySelector('#usa-accordion-txt');
let gov_banner = document.querySelector('#gov-banner');
accordion_txt.addEventListener('click', function () {
  this.classList.toggle('active');
  toggleBanner(gov_banner);
});

function toggleBanner(element) {
  if (element.getAttribute("hidden") !== null) {
    element.removeAttribute("hidden");
    element.style.display = "block";
  } else {
    element.setAttribute("hidden", "");
    element.style.display = "none";
  }
}

function classApplicator(elements, action, className) {
  for (var i = 0; i < elements.length; i++) {
    if (action == 'add') {
      elements[i].classList.add(className);
    } else { // action == 'remove'
      elements[i].classList.remove(className);
    }
  }

}

function setCurrentNavItem() {
  /* Note: this sets the usa-current and is-active classes for both the left sidebar and the mega menu */

  // Remove usa-current and is-active classes
  var activeElements = document.getElementsByClassName("usa-nav__submenu-item");
  classApplicator(activeElements, 'remove', 'is-active');

  var currentElements = document.getElementsByClassName("usa-current");
  classApplicator(activeElements, 'remove', 'usa-current');

  var path = window.location.pathname;

  // Reapply usa-current and is-active classes
  if ((path.search('index.php') >= 0 && path.length > path.search('index.php') + 10) || path.search('features/')) {
    var currentLink;
    var isFeature = false;
    if (path.search('features/') > 0) {
      isFeature = true;
      var lastSlashIndex = path.lastIndexOf('/');
      path = path.substring(0, lastSlashIndex);
    }
    currentLink = document.querySelectorAll("[href='" + path + "']");
    for (var i = 0; i < currentLink.length; i++) {
      if (typeof currentLink[i] !== "undefined") {
        currentLink[i].classList.add("usa-current");
        currentLink[i].classList.add("is-active");
        currentLink[i].addEventListener('click', function (event) {
          if (!isFeature) { // If link is not a feature/, prevent default clicking event
            event.preventDefault();
          }
        });

        var primaryListItems = document.querySelectorAll('li.usa-nav__primary-item');
        for (var j = 0; j < primaryListItems.length; j++) {
          var isActiveElements = primaryListItems[j].getElementsByClassName('is-active');
          if (isActiveElements.length > 0) {
            var item = primaryListItems[j].getElementsByTagName('button');
            classApplicator(item, 'add', 'usa-current');
          }
        }
      }
    }
  }
}

setCurrentNavItem(); // Script runs on page load 

function makeNewsAndFeaturesClickable() {
  var url = window.location.href;
  if (url.includes("newsroom") || url.includes("features?view")) {
    var navElements = document.getElementsByClassName("usa-nav__link");
    if (url.includes("newsroom")) {
      var newsroomAnchors = document.querySelectorAll('a[href*="newsroom"]');
      for (var i = 0; i < newsroomAnchors.length; i++) {
        // Add classes usa-current and is-active classes
        newsroomAnchors[i].classList.add("usa-current");
        newsroomAnchors[i].classList.add("is-active");
      }
    }

    if (url.includes("features?view")) {
      var featruesAnchors = document.querySelectorAll('a[href*="features"]');
      for (var i = 0; i < featruesAnchors.length; i++) {
        // featruesAnchors[i].setAttribute('href', 'javascript:history.back();');

        // featruesAnchors[i].setAttribute('onclick', 'window.location.reload(true);');

        featruesAnchors[i].onclick = function (event) {
          event.preventDefault();

          // Get the current URL
          var url = new URL(window.location.href);

          // Clear the search parameters
          url.search = '';

          // Update the URL without reloading the page
          window.history.pushState({}, document.title, url.toString());

          // Reload the page
          window.location.reload(true);
        };
      }
    }
  }

}
makeNewsAndFeaturesClickable(); // Script runs on page load 

// var url = window.location.href;
// if (url.includes("secure-innovation") && !url.includes("secure-innovation?start=")) {
//   var newHref = url + '?start=0';

  var anchors = document.querySelectorAll('a[href*="secure-innovation"]:not([href*="secure-innovation?start="])');
  anchors.forEach(function (anchor) {
    anchor.setAttribute('href', anchor.getAttribute('href') + '?start=0');
    anchor.onclick = function (event) {
      event.preventDefault();
      window.location.href = anchor.getAttribute('href');
      window.history.pushState({}, document.title, anchor.getAttribute('href'));
      window.location.reload(true);

    }

  });

// Get the button
let topbutton = document.getElementById("topBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function () { scrollFunction() };

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    topbutton.style.display = "block";
  } else {
    topbutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0; // For Safari
  document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
}


function toggleMore(id) {
  var moreText = document.getElementById(id + "-more");
  var btnText = document.getElementById(id + "-btn");

  if (moreText.style.display === "inline") {
    btnText.innerHTML = "read more";
    moreText.style.display = "none";
  } else {
    btnText.innerHTML = "read less";
    moreText.style.display = "inline";
  }
}

// Select the tab list element tabListElement will be defined on NCSC Secure Innnovation page
const tabListElement = document.getElementById('myTab');

if (tabListElement) {
  // Create an observer instance
  const observer = new MutationObserver((mutationsList, observer) => {
      for (const mutation of mutationsList) {
          if (mutation.type === 'attributes' && mutation.attributeName === 'view') {
              const newValue = tabListElement.getAttribute('view');
              if (newValue !== 'tabs') {
                tabListElement.setAttribute('view', 'tabs');
              }
          }
      }
  });
  
  // Configuration of the observer
  const config = { attributes: true, attributeFilter: ['view'] };
  
  // Start observing the target element
  observer.observe(tabListElement, config);
}
